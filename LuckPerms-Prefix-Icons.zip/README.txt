LuckPerms Admin / Owner prefix icons
====================================

Символы (скопируй 1-в-1):

  ADMIN  →  
  OWNER  →  

Unicode:
  ADMIN = U+E001
  OWNER = U+E002

────────────────────────────────────
Вариант 1 (рекомендуется) — через MiniMessage
────────────────────────────────────
Если у тебя LuckPerms с Adventure/MiniMessage (почти всегда на Paper 1.21):

  /lp group admin meta setprefix 100 "<font:minecraft:lpicons></font> "
  /lp group owner meta setprefix 100 "<font:minecraft:lpicons></font> "

────────────────────────────────────
Вариант 2 — просто символ (если default.json подхватился)
────────────────────────────────────
  /lp group admin meta setprefix 100 " "
  /lp group owner meta setprefix 100 " "

────────────────────────────────────
Как заменить картинки
────────────────────────────────────
Положи свои PNG сюда:

  assets/minecraft/textures/font/admin.png
  assets/minecraft/textures/font/owner.png

Рекомендации:
  • Размер 8×8 или 16×16
  • Прозрачный фон
  • Без огромных полей по краям (иначе иконка будет мелкой)

После замены:
  1. Пересобери zip
  2. Положи пак на сервер (server.properties → resource-pack=...)
     или раздай игрокам
  3. /lp reload  +  перезайди в игру

Пак совместим с 1.20.5 – 1.21.x.
