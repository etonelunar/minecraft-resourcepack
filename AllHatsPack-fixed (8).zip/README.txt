All Hats Pack 1.21.11 — CMD only (no anvil)

CMD 1001 — Among Us
/give @p carved_pumpkin[custom_model_data={floats:[1001]},custom_name={"text":"Among Us","italic":false}] 1

CMD 1002 — Books Hat
/give @p carved_pumpkin[custom_model_data={floats:[1002]},custom_name={"text":"Books Hat","italic":false}] 1

CMD 1003 — Chef Hat
/give @p carved_pumpkin[custom_model_data={floats:[1003]},custom_name={"text":"Chef Hat","italic":false}] 1

CMD 1004 — Christmas Hat
/give @p carved_pumpkin[custom_model_data={floats:[1004]},custom_name={"text":"Christmas Hat","italic":false}] 1

CMD 1005 — Demon Horns
/give @p carved_pumpkin[custom_model_data={floats:[1005]},custom_name={"text":"Demon Horns","italic":false}] 1

CMD 1006 — Eye Hat
/give @p carved_pumpkin[custom_model_data={floats:[1006]},custom_name={"text":"Eye Hat","italic":false}] 1

CMD 1007 — Halo
/give @p carved_pumpkin[custom_model_data={floats:[1007]},custom_name={"text":"Halo","italic":false}] 1

CMD 1008 — Headset
/give @p carved_pumpkin[custom_model_data={floats:[1008]},custom_name={"text":"Headset","italic":false}] 1

CMD 1009 — Miner Hat
/give @p carved_pumpkin[custom_model_data={floats:[1009]},custom_name={"text":"Miner Hat","italic":false}] 1

CMD 1010 — Sad Hat
/give @p carved_pumpkin[custom_model_data={floats:[1010]},custom_name={"text":"Sad Hat","italic":false}] 1

CMD 1011 — Safety Hat
/give @p carved_pumpkin[custom_model_data={floats:[1011]},custom_name={"text":"Safety Hat","italic":false}] 1

CMD 1012 — Saiko Hat
/give @p carved_pumpkin[custom_model_data={floats:[1012]},custom_name={"text":"Saiko Hat","italic":false}] 1

CMD 1013 — Straw Hat
/give @p carved_pumpkin[custom_model_data={floats:[1013]},custom_name={"text":"Straw Hat","italic":false}] 1

CMD 1014 — Swimming Goggles
/give @p carved_pumpkin[custom_model_data={floats:[1014]},custom_name={"text":"Swimming Goggles","italic":false}] 1

CMD 1015 — Toilet Paper
/give @p carved_pumpkin[custom_model_data={floats:[1015]},custom_name={"text":"Toilet Paper","italic":false}] 1

CMD 1016 — Top Hat
/give @p carved_pumpkin[custom_model_data={floats:[1016]},custom_name={"text":"Top Hat","italic":false}] 1

CMD 1017 — Traffic Cone
/give @p carved_pumpkin[custom_model_data={floats:[1017]},custom_name={"text":"Traffic Cone","italic":false}] 1

CMD 1018 — Unblocker
/give @p carved_pumpkin[custom_model_data={floats:[1018]},custom_name={"text":"Unblocker","italic":false}] 1

CMD 1019 — Western Hat
/give @p carved_pumpkin[custom_model_data={floats:[1019]},custom_name={"text":"Western Hat","italic":false}] 1

CMD 1020 — Witch Hat
/give @p carved_pumpkin[custom_model_data={floats:[1020]},custom_name={"text":"Witch Hat","italic":false}] 1

CMD 1021 — Banana Peel
/give @p carved_pumpkin[custom_model_data={floats:[1021]},custom_name={"text":"Banana Peel","italic":false}] 1

CMD 1022 — Cigarette
/give @p carved_pumpkin[custom_model_data={floats:[1022]},custom_name={"text":"Cigarette","italic":false}] 1

CMD 1023 — Cooking Head
/give @p carved_pumpkin[custom_model_data={floats:[1023]},custom_name={"text":"Cooking Head","italic":false}] 1

CMD 1024 — Cover Mask
/give @p carved_pumpkin[custom_model_data={floats:[1024]},custom_name={"text":"Cover Mask","italic":false}] 1

CMD 1025 — Cowboy Hat
/give @p carved_pumpkin[custom_model_data={floats:[1025]},custom_name={"text":"Cowboy Hat","italic":false}] 1

CMD 1026 — Crown
/give @p carved_pumpkin[custom_model_data={floats:[1026]},custom_name={"text":"Crown","italic":false}] 1

CMD 1027 — Cylinder
/give @p carved_pumpkin[custom_model_data={floats:[1027]},custom_name={"text":"Cylinder","italic":false}] 1

CMD 1028 — Dark Cylinder
/give @p carved_pumpkin[custom_model_data={floats:[1028]},custom_name={"text":"Dark Cylinder","italic":false}] 1

CMD 1029 — Dwarf Hat
/give @p carved_pumpkin[custom_model_data={floats:[1029]},custom_name={"text":"Dwarf Hat","italic":false}] 1

CMD 1030 — Cat Ears
/give @p carved_pumpkin[custom_model_data={floats:[1030]},custom_name={"text":"Cat Ears","italic":false}] 1

CMD 1031 — Garbage Hat
/give @p carved_pumpkin[custom_model_data={floats:[1031]},custom_name={"text":"Garbage Hat","italic":false}] 1

CMD 1032 — Halo of the Sun
/give @p carved_pumpkin[custom_model_data={floats:[1032]},custom_name={"text":"Halo of the Sun","italic":false}] 1

CMD 1033 — Simple Hat
/give @p carved_pumpkin[custom_model_data={floats:[1033]},custom_name={"text":"Simple Hat","italic":false}] 1

CMD 1034 — Hotdog Hat
/give @p carved_pumpkin[custom_model_data={floats:[1034]},custom_name={"text":"Hotdog Hat","italic":false}] 1

CMD 1035 — Jester Hat
/give @p carved_pumpkin[custom_model_data={floats:[1035]},custom_name={"text":"Jester Hat","italic":false}] 1

CMD 1036 — Knight Helmet
/give @p carved_pumpkin[custom_model_data={floats:[1036]},custom_name={"text":"Knight Helmet","italic":false}] 1

CMD 1037 — Miner Helmet
/give @p carved_pumpkin[custom_model_data={floats:[1037]},custom_name={"text":"Miner Helmet","italic":false}] 1

CMD 1038 — Queen Crown
/give @p carved_pumpkin[custom_model_data={floats:[1038]},custom_name={"text":"Queen Crown","italic":false}] 1

CMD 1039 — Sombrero
/give @p carved_pumpkin[custom_model_data={floats:[1039]},custom_name={"text":"Sombrero","italic":false}] 1

CMD 1040 — Straw Head
/give @p carved_pumpkin[custom_model_data={floats:[1040]},custom_name={"text":"Straw Head","italic":false}] 1

CMD 1041 — Sunglasses
/give @p carved_pumpkin[custom_model_data={floats:[1041]},custom_name={"text":"Sunglasses","italic":false}] 1

CMD 1042 — Traffic Cone 2
/give @p carved_pumpkin[custom_model_data={floats:[1042]},custom_name={"text":"Traffic Cone 2","italic":false}] 1

CMD 1043 — TV Head
/give @p carved_pumpkin[custom_model_data={floats:[1043]},custom_name={"text":"TV Head","italic":false}] 1

CMD 1044 — Visor
/give @p carved_pumpkin[custom_model_data={floats:[1044]},custom_name={"text":"Visor","italic":false}] 1

CMD 1045 — Water Mask & Straw
/give @p carved_pumpkin[custom_model_data={floats:[1045]},custom_name={"text":"Water Mask & Straw","italic":false}] 1

--- RoyaleMC hats ---

CMD 1046 — Bandana 1
/give @p carved_pumpkin[custom_model_data={floats:[1046]},custom_name={"text":"Bandana 1","italic":false}] 1

CMD 1047 — Bandana 2
/give @p carved_pumpkin[custom_model_data={floats:[1047]},custom_name={"text":"Bandana 2","italic":false}] 1

CMD 1048 — Bandana 3
/give @p carved_pumpkin[custom_model_data={floats:[1048]},custom_name={"text":"Bandana 3","italic":false}] 1

CMD 1049 — Cap
/give @p carved_pumpkin[custom_model_data={floats:[1049]},custom_name={"text":"Cap","italic":false}] 1

CMD 1050 — Captain Hat
/give @p carved_pumpkin[custom_model_data={floats:[1050]},custom_name={"text":"Captain Hat","italic":false}] 1

CMD 1051 — Royale Chef Hat
/give @p carved_pumpkin[custom_model_data={floats:[1051]},custom_name={"text":"Royale Chef Hat","italic":false}] 1

CMD 1052 — Cosmo Hat
/give @p carved_pumpkin[custom_model_data={floats:[1052]},custom_name={"text":"Cosmo Hat","italic":false}] 1

CMD 1053 — Cow Boy Hat
/give @p carved_pumpkin[custom_model_data={floats:[1053]},custom_name={"text":"Cow Boy Hat","italic":false}] 1

CMD 1054 — Cow Boy Hat Broke
/give @p carved_pumpkin[custom_model_data={floats:[1054]},custom_name={"text":"Cow Boy Hat Broke","italic":false}] 1

CMD 1055 — Death Hat
/give @p carved_pumpkin[custom_model_data={floats:[1055]},custom_name={"text":"Death Hat","italic":false}] 1

CMD 1056 — Demon Hat
/give @p carved_pumpkin[custom_model_data={floats:[1056]},custom_name={"text":"Demon Hat","italic":false}] 1

CMD 1057 — Farm Hat
/give @p carved_pumpkin[custom_model_data={floats:[1057]},custom_name={"text":"Farm Hat","italic":false}] 1

CMD 1058 — Fire Hat
/give @p carved_pumpkin[custom_model_data={floats:[1058]},custom_name={"text":"Fire Hat","italic":false}] 1

CMD 1059 — Football Helmet
/give @p carved_pumpkin[custom_model_data={floats:[1059]},custom_name={"text":"Football Helmet","italic":false}] 1

CMD 1060 — Gas Mask
/give @p carved_pumpkin[custom_model_data={floats:[1060]},custom_name={"text":"Gas Mask","italic":false}] 1

CMD 1061 — Gray Hat
/give @p carved_pumpkin[custom_model_data={floats:[1061]},custom_name={"text":"Gray Hat","italic":false}] 1

CMD 1062 — King Hat
/give @p carved_pumpkin[custom_model_data={floats:[1062]},custom_name={"text":"King Hat","italic":false}] 1

CMD 1063 — Knight Hat
/give @p carved_pumpkin[custom_model_data={floats:[1063]},custom_name={"text":"Knight Hat","italic":false}] 1

CMD 1064 — Maniac Mask
/give @p carved_pumpkin[custom_model_data={floats:[1064]},custom_name={"text":"Maniac Mask","italic":false}] 1

CMD 1065 — Royale Miner Hat
/give @p carved_pumpkin[custom_model_data={floats:[1065]},custom_name={"text":"Royale Miner Hat","italic":false}] 1

CMD 1066 — Pink Hat
/give @p carved_pumpkin[custom_model_data={floats:[1066]},custom_name={"text":"Pink Hat","italic":false}] 1

CMD 1067 — Pirate Hat
/give @p carved_pumpkin[custom_model_data={floats:[1067]},custom_name={"text":"Pirate Hat","italic":false}] 1

CMD 1068 — Sheriff Hat
/give @p carved_pumpkin[custom_model_data={floats:[1068]},custom_name={"text":"Sheriff Hat","italic":false}] 1

CMD 1069 — Winter Hat
/give @p carved_pumpkin[custom_model_data={floats:[1069]},custom_name={"text":"Winter Hat","italic":false}] 1

